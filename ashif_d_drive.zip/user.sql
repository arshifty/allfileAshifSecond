-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2021 at 08:40 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user`
--

-- --------------------------------------------------------

--
-- Table structure for table `userregs`
--

CREATE TABLE `userregs` (
  `id` int(11) NOT NULL,
  `userName` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userregs`
--

INSERT INTO `userregs` (`id`, `userName`, `contact`, `password`, `city`, `country`, `code`, `createdAt`, `updatedAt`) VALUES
(15, 'ashif rahman', '555', 'dd', 'barisal', 'bangladesh', '4533', '2021-02-12 09:19:45', '2021-02-12 10:52:09'),
(22, 'aminul', '4344', 'ss', 'dhaka', 'vv', '4566', '2021-02-12 10:52:47', '2021-02-15 12:37:03'),
(23, 'mokbul', '1845041010', 'qq', 'aaa', 'sss', 'ddd', '2021-02-16 11:01:35', '2021-02-16 11:01:35'),
(24, 'cxv', '435', 'ee', 'rr', 'tt', 'tt', '2021-02-16 13:33:44', '2021-02-16 13:33:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `userregs`
--
ALTER TABLE `userregs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `userregs`
--
ALTER TABLE `userregs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
